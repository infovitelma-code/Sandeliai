
import React, { useMemo } from 'react';
import { WoodLog, WarehouseSetting } from '../types';
import StatCard from './StatCard';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from 'recharts';

interface DashboardProps {
  logs: WoodLog[];
  settings: WarehouseSetting[];
}

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

const Dashboard: React.FC<DashboardProps> = ({ logs, settings }) => {
  const stats = useMemo(() => {
    return settings.map(s => {
      const warehouseLogs = logs.filter(l => l.sandelys === s.name);
      const totalVolume = warehouseLogs.reduce((acc, l) => acc + l.kiekis, 0);
      const totalSales = warehouseLogs.reduce((acc, l) => acc + (l.kiekis * l.kaina), 0);
      const totalProdCost = warehouseLogs.reduce((acc, l) => acc + (l.kiekis * l.gamyba), 0);
      const totalPap = warehouseLogs.reduce((acc, l) => acc + l.pap_pajamos, 0);
      const netProfit = (totalSales - totalProdCost + totalPap) - s.cost;
      
      const distribution = warehouseLogs.reduce((acc: any, l) => {
        acc[l.sortimentas] = (acc[l.sortimentas] || 0) + l.kiekis;
        return acc;
      }, {});

      const chartData = Object.keys(distribution).map(name => ({
        name,
        value: Number(distribution[name].toFixed(2))
      }));

      return {
        name: s.name,
        investment: s.cost,
        capacity: s.volume,
        currentVolume: totalVolume,
        totalSales,
        totalPap,
        netProfit,
        chartData
      };
    });
  }, [logs, settings]);

  if (settings.length === 0) {
    return (
      <div className="text-center py-20">
        <i className="fas fa-chart-line text-6xl text-slate-200 mb-4"></i>
        <h3 className="text-xl font-semibold text-slate-600">Nėra duomenų ataskaitoms</h3>
        <p className="text-slate-400">Pirmiausia pridėkite sandėlius nustatymuose.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fadeIn">
      {stats.map(s => (
        <div key={s.name} className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
          <div className="bg-slate-50 border-bottom border-slate-100 px-6 py-4 flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
              <i className="fas fa-warehouse text-emerald-600"></i>
              {s.name}
            </h2>
            <span className="text-xs font-semibold px-2.5 py-1 rounded bg-emerald-100 text-emerald-800">
              Užpildymas: {((s.currentVolume / s.capacity) * 100).toFixed(1)}%
            </span>
          </div>
          
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
              <StatCard 
                title="Investicija" 
                value={`-${s.investment.toLocaleString()}€`} 
                icon="fas fa-money-bill-wave" 
                color="border-red-500"
              />
              <StatCard 
                title="Pardavimai" 
                value={`+${s.totalSales.toLocaleString()}€`} 
                icon="fas fa-chart-bar" 
                color="border-blue-500"
                description={`+${s.totalPap.toLocaleString()}€ papildomai`}
              />
              <StatCard 
                title="Likutis (Pelnas)" 
                value={`${s.netProfit.toLocaleString()}€`} 
                icon="fas fa-coins" 
                color="border-emerald-500"
              />
              <StatCard 
                title="Kiekis" 
                value={`${s.currentVolume.toFixed(2)} m³`} 
                icon="fas fa-tree" 
                color="border-slate-800"
                description={`iš ${s.capacity} m³`}
              />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
              <div>
                <h4 className="text-sm font-semibold text-slate-500 mb-4 uppercase">Sortimentų pasiskirstymas</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={s.chartData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={80}
                        fill="#8884d8"
                        paddingAngle={5}
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {s.chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
              
              <div className="space-y-4">
                 <h4 className="text-sm font-semibold text-slate-500 mb-2 uppercase">Išsami informacija</h4>
                 <div className="space-y-3">
                   {s.chartData.map((d, i) => (
                     <div key={d.name} className="flex items-center justify-between text-sm border-b border-slate-50 pb-2">
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                         <span className="text-slate-600">{d.name}</span>
                       </div>
                       <span className="font-semibold text-slate-800">{d.value} m³</span>
                     </div>
                   ))}
                 </div>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default Dashboard;
