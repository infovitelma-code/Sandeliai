
import React, { useState } from 'react';
import { WoodLog } from '../types';

interface LogTableProps {
  logs: WoodLog[];
  onEdit: (log: WoodLog) => void;
  onDelete: (num: string, date: string) => void;
  onInvoice: (num: string) => void;
  onRefresh: () => void;
}

const LogTable: React.FC<LogTableProps> = ({ logs, onEdit, onDelete, onInvoice, onRefresh }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLogs = logs.filter(l => 
    l.num.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.sandelys.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.gavejas.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 animate-fadeIn">
      <div className="p-6 border-b border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <h2 className="text-lg font-bold text-slate-800">Važtaraščių registras</h2>
        <div className="flex items-center gap-3">
          <div className="relative">
            <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"></i>
            <input 
              type="text" 
              placeholder="Ieškoti pagal Nr., Sandėlį..." 
              className="pl-10 pr-4 py-2 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-sm w-full md:w-64"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button 
            onClick={onRefresh}
            className="p-2 text-slate-500 hover:text-emerald-600 transition-colors"
            title="Atnaujinti"
          >
            <i className="fas fa-sync-alt"></i>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50 text-slate-500 text-xs font-semibold uppercase tracking-wider">
              <th className="px-6 py-4">Data</th>
              <th className="px-6 py-4">Nr.</th>
              <th className="px-6 py-4">Sandėlys</th>
              <th className="px-6 py-4">Kiekis (m³)</th>
              <th className="px-6 py-4">Pastabos</th>
              <th className="px-6 py-4 text-right">Veiksmai</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredLogs.length > 0 ? filteredLogs.map((log, idx) => (
              <tr key={`${log.num}-${idx}`} className={`hover:bg-slate-50 transition-colors ${log.kiekis === 0 ? 'bg-red-50/30' : ''}`}>
                <td className="px-6 py-4 text-sm whitespace-nowrap">{log.data}</td>
                <td className="px-6 py-4 text-sm font-semibold text-slate-800">{log.num}</td>
                <td className="px-6 py-4">
                   <span className={`text-xs px-2 py-1 rounded font-medium ${log.sandelys === 'NENUSTATYTA' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-600'}`}>
                    {log.sandelys}
                   </span>
                </td>
                <td className="px-6 py-4 text-sm">{log.kiekis}</td>
                <td className="px-6 py-4 text-sm text-slate-400">
                  {log.pastabos?.startsWith('http') ? (
                    <a href={log.pastabos} target="_blank" className="text-emerald-600 hover:underline">Nuoroda</a>
                  ) : log.pastabos}
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end items-center gap-2">
                    <button 
                      onClick={() => onInvoice(log.num)}
                      className="text-blue-600 hover:bg-blue-50 p-2 rounded transition-colors"
                      title="Generuoti sąskaitą"
                    >
                      <i className="fas fa-file-invoice"></i>
                    </button>
                    <button 
                      onClick={() => onEdit(log)}
                      className="text-slate-600 hover:bg-slate-100 p-2 rounded transition-colors"
                      title="Redaguoti"
                    >
                      <i className="fas fa-edit"></i>
                    </button>
                    <button 
                      onClick={() => onDelete(log.num, log.data)}
                      className="text-red-500 hover:bg-red-50 p-2 rounded transition-colors"
                      title="Ištrinti"
                    >
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={6} className="px-6 py-20 text-center text-slate-400">
                  Važtaraščių nerasta.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LogTable;
