
import React, { useState } from 'react';
import { WarehouseSetting } from '../types';

interface SettingsProps {
  settings: WarehouseSetting[];
  onSave: (setting: WarehouseSetting) => void;
  onDelete: (name: string) => void;
  isLoading: boolean;
}

const Settings: React.FC<SettingsProps> = ({ settings, onSave, onDelete, isLoading }) => {
  const [formData, setFormData] = useState<WarehouseSetting>({
    name: '',
    cost: 0,
    volume: 0,
    prodCost: 0
  });

  const [copySuccess, setCopySuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'name' ? value : parseFloat(value) || 0
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    setFormData({ name: '', cost: 0, volume: 0, prodCost: 0 });
  };

  const handleEdit = (s: WarehouseSetting) => {
    setFormData(s);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const appsScriptCode = `// MEDIENOS PRO BACKEND SCRIPT
const SS = SpreadsheetApp.getActiveSpreadsheet();
const LOGS_SHEET = "LOGS";
const SETTINGS_SHEET = "SETTINGS";

function doGet() {
  const logs = SS.getSheetByName(LOGS_SHEET).getDataRange().getValues().slice(1);
  const settings = SS.getSheetByName(SETTINGS_SHEET).getDataRange().getValues().slice(1);
  return ContentService.createTextOutput(JSON.stringify({logs, settings}))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  const data = JSON.parse(e.postData.contents);
  const sheetLogs = SS.getSheetByName(LOGS_SHEET);
  const sheetSettings = SS.getSheetByName(SETTINGS_SHEET);

  if (data.type === "log") {
    sheetLogs.appendRow([data.num, data.data, data.sandelys, data.vezejas, data.gavejas, data.sortimentas, data.ilgis, data.kiekis, data.kaina, data.gamyba, data.pastabos, data.pap_pajamos, data.pap_pajamos_desc, new Date(), data.is_transfer]);
  } else if (data.type === "edit_log") {
    const rows = sheetLogs.getDataRange().getValues();
    for (let i = 1; i < rows.length; i++) {
      if (String(rows[i][0]) === String(data.old_num) && formatDate(rows[i][1]) === formatDate(data.old_date)) {
        sheetLogs.getRange(i + 1, 1, 1, 13).setValues([[data.num, data.data, data.sandelys, data.vezejas, data.gavejas, data.sortimentas, data.ilgis, data.kiekis, data.kaina, data.gamyba, data.pastabos, data.pap_pajamos, data.pap_pajamos_desc]]);
        break;
      }
    }
  } else if (data.type === "delete_log_entry") {
    const rows = sheetLogs.getDataRange().getValues();
    for (let i = rows.length - 1; i >= 1; i--) {
      if (String(rows[i][0]) === String(data.num) && formatDate(rows[i][1]) === formatDate(data.data)) {
        sheetLogs.deleteRow(i + 1);
        break;
      }
    }
  } else if (data.type === "setting") {
    const rows = sheetSettings.getDataRange().getValues();
    let found = false;
    for (let i = 1; i < rows.length; i++) {
      if (rows[i][0] === data.name) {
        sheetSettings.getRange(i + 1, 1, 1, 4).setValues([[data.name, data.cost, data.volume, data.prodCost]]);
        found = true;
        break;
      }
    }
    if (!found) sheetSettings.appendRow([data.name, data.cost, data.volume, data.prodCost]);
  } else if (data.type === "delete_setting") {
    const rows = sheetSettings.getDataRange().getValues();
    for (let i = rows.length - 1; i >= 1; i--) {
      if (rows[i][0] === data.name) {
        sheetSettings.deleteRow(i + 1);
        break;
      }
    }
  }
  return ContentService.createTextOutput("Success").setMimeType(ContentService.MimeType.TEXT);
}

function formatDate(date) {
  if (!date) return "";
  return Utilities.formatDate(new Date(date), Session.getScriptTimeZone(), "yyyy-MM-dd");
}`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(appsScriptCode);
    setCopySuccess(true);
    setTimeout(() => setCopySuccess(false), 2000);
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Setup Guide */}
      <div className="bg-emerald-900 text-emerald-50 rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8">
          <div className="flex items-center gap-4 mb-6">
            <div className="bg-emerald-500 p-3 rounded-xl">
              <i className="fas fa-magic text-2xl"></i>
            </div>
            <div>
              <h2 className="text-2xl font-bold">Sistemos paruošimas</h2>
              <p className="text-emerald-200 text-sm">Atlikite šiuos žingsnius, kad įgalintumėte duomenų saugojimą.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-emerald-700 rounded-full flex items-center justify-center font-bold">1</div>
                <div>
                  <p className="font-bold">Sukurkite Google Sheet</p>
                  <p className="text-sm text-emerald-300">Sukurkite naują lentelę ir pridėkite lapus pavadinimais <code className="bg-emerald-800 px-1 rounded">LOGS</code> ir <code className="bg-emerald-800 px-1 rounded">SETTINGS</code>.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-emerald-700 rounded-full flex items-center justify-center font-bold">2</div>
                <div>
                  <p className="font-bold">Įklijuokite Apps Script kodą</p>
                  <p className="text-sm text-emerald-300">Eikite į Extensions - Apps Script ir įklijuokite kodą iš dešinės.</p>
                  <button 
                    onClick={copyToClipboard}
                    className="mt-2 bg-white text-emerald-900 px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-2 hover:bg-emerald-100 transition-colors"
                  >
                    <i className={`fas ${copySuccess ? 'fa-check' : 'fa-copy'}`}></i>
                    {copySuccess ? 'NUKOPIJUOTA!' : 'KOPIJUOTI BACKEND KODĄ'}
                  </button>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-emerald-700 rounded-full flex items-center justify-center font-bold">3</div>
                <div>
                  <p className="font-bold">Paskelbkite (Deploy)</p>
                  <p className="text-sm text-emerald-300">Spauskite Deploy - New Deployment - Web App. Nukopijuotą URL įklijuokite į <code className="bg-emerald-800 px-1 rounded">apiService.ts</code> failą.</p>
                </div>
              </div>
            </div>

            <div className="bg-emerald-950 rounded-xl p-4 overflow-hidden border border-emerald-800">
              <div className="flex justify-between items-center mb-2 text-xs text-emerald-500 font-mono uppercase">
                <span>backend-script.gs</span>
                <span>google apps script</span>
              </div>
              <pre className="text-[10px] leading-tight font-mono text-emerald-400 overflow-y-auto max-h-48 scrollbar-hide opacity-50">
                {appsScriptCode}
              </pre>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-8">
        <h2 className="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
          <i className="fas fa-warehouse text-slate-400"></i>
          🏗️ Sandėlių Valdymas
        </h2>
        
        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Sandėlio pavadinimas</label>
            <input required name="name" value={formData.name} onChange={handleChange} className="w-full px-4 py-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-emerald-500/20" placeholder="Pvz. Miškas-1" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Investicija (€)</label>
            <input type="number" name="cost" value={formData.cost} onChange={handleChange} className="w-full px-4 py-2 border border-slate-200 rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Tūris (m³)</label>
            <input type="number" name="volume" value={formData.volume} onChange={handleChange} className="w-full px-4 py-2 border border-slate-200 rounded-lg" />
          </div>
          <div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Gamybos kaina (€/m³)</label>
            <input type="number" step="0.1" name="prodCost" value={formData.prodCost} onChange={handleChange} className="w-full px-4 py-2 border border-slate-200 rounded-lg" />
          </div>
          <div className="md:col-span-4 flex justify-end">
            <button 
              type="submit" 
              disabled={isLoading || !formData.name}
              className="bg-slate-800 hover:bg-slate-900 text-white font-bold px-8 py-3 rounded-xl transition-all disabled:opacity-50 shadow-lg shadow-slate-200"
            >
              {isLoading ? 'Kraunama...' : 'IŠSAUGOTI SANDĖLĮ'}
            </button>
          </div>
        </form>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 text-slate-500 text-xs font-semibold uppercase tracking-wider">
              <th className="px-6 py-4">Pavadinimas</th>
              <th className="px-6 py-4">Investicija</th>
              <th className="px-6 py-4">Talpa</th>
              <th className="px-6 py-4">Gamyba</th>
              <th className="px-6 py-4 text-right">Veiksmai</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {settings.length > 0 ? settings.map(s => (
              <tr key={s.name} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-bold text-slate-800">{s.name}</td>
                <td className="px-6 py-4">{s.cost.toLocaleString()} €</td>
                <td className="px-6 py-4">{s.volume} m³</td>
                <td className="px-6 py-4 font-medium text-emerald-600">{s.prodCost} €/m³</td>
                <td className="px-6 py-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => handleEdit(s)} className="text-slate-400 hover:text-emerald-600 p-2 rounded transition-colors">
                      <i className="fas fa-edit"></i>
                    </button>
                    <button onClick={() => onDelete(s.name)} className="text-slate-400 hover:text-red-600 p-2 rounded transition-colors">
                      <i className="fas fa-trash"></i>
                    </button>
                  </div>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-slate-400 italic text-sm">Sandėlių nėra sukurta. Pridėkite pirmąjį aukščiau esančia forma.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Settings;
