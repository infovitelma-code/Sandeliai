
import { WoodLog, WarehouseSetting, ApiResponse } from '../types';

// Naudotojas turi pasikeisti šį URL į savo Apps Script Web App URL
const SCRIPT_URL = "https://script.google.com/macros/s/AKfycby9bZ2ybx6PPRhuFvXENMqZSKm92--ioPLpH_FD-eSCpdpWSskt0c4qNnFPAH6ev7uu/exec";

export const apiService = {
  async fetchAll(): Promise<{ logs: WoodLog[], settings: WarehouseSetting[] }> {
    try {
      const response = await fetch(SCRIPT_URL);
      const data: ApiResponse = await response.json();

      const logs: WoodLog[] = data.logs.map(row => ({
        num: String(row[0] || ''),
        data: this.formatDate(row[1]),
        sandelys: String(row[2] || ''),
        vezejas: String(row[3] || ''),
        gavejas: String(row[4] || ''),
        sortimentas: String(row[5] || ''),
        ilgis: String(row[6] || ''),
        kiekis: Number(row[7]) || 0,
        kaina: Number(row[8]) || 0,
        gamyba: Number(row[9]) || 0,
        pastabos: String(row[10] || ''),
        pap_pajamos: Number(row[11]) || 0,
        pap_pajamos_desc: String(row[12] || ''),
        is_transfer: row[14] === true || row[14] === 'TRUE'
      }));

      const settings: WarehouseSetting[] = data.settings.map(row => ({
        name: String(row[0] || ''),
        cost: Number(row[1]) || 0,
        volume: Number(row[2]) || 0,
        prodCost: Number(row[3]) || 0
      }));

      return { logs, settings };
    } catch (error) {
      console.error("Klaida kraunant duomenis:", error);
      return { logs: [], settings: [] };
    }
  },

  async saveLog(log: WoodLog, isEdit: boolean = false, oldNum?: string, oldDate?: string): Promise<void> {
    const payload = {
      type: isEdit ? "edit_log" : "log",
      ...log,
      old_num: oldNum,
      old_date: oldDate
    };
    await this.post(payload);
  },

  async deleteLog(num: string, date: string): Promise<void> {
    await this.post({ type: "delete_log_entry", num, data: date });
  },

  async saveSetting(setting: WarehouseSetting): Promise<void> {
    await this.post({ type: "setting", ...setting });
  },

  async deleteSetting(name: string): Promise<void> {
    await this.post({ type: "delete_setting", name });
  },

  async sendInvoice(nr: string): Promise<void> {
    await this.post({ type: "send_invoice", nr });
  },

  async post(data: any): Promise<any> {
    // Naudojame no-cors, nes Apps Script redirectai dažnai blokuojami CORS
    return fetch(SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',
      body: JSON.stringify(data)
    });
  },

  formatDate(val: any): string {
    if (!val) return "";
    const d = new Date(val);
    return isNaN(d.getTime()) ? String(val) : d.toISOString().split('T')[0];
  }
};
